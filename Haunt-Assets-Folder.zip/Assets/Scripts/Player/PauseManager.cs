﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class PauseManager : MonoBehaviour
{
    public GameObject pausePanel;
	int i = 1;
	public string sceneName;
	
	void Start(){
		//I enabled this for some artistic flare but remove it if you want a faster framerate
		Application.targetFrameRate = 24;
	}
	
	void Update(){
		if (Input.GetKeyDown(KeyCode.R)){
			SceneManager.LoadScene(sceneName);
		}
		
		if (Input.GetKeyDown(KeyCode.Escape)){
			i *= -1;
		}
		
		if (i > 0){
			pausePanel.SetActive(false);
			Time.timeScale = 1f;
			
			Cursor.visible = false;
			Cursor.lockState = CursorLockMode.Locked;
		}else if (i < 0){
			pausePanel.SetActive(true);
			Time.timeScale = 0f;
			
			Cursor.visible = true;
			Cursor.lockState = CursorLockMode.None;
		}
	}
}
