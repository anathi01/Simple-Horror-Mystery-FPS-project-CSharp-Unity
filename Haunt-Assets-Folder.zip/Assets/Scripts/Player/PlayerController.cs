﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerController : MonoBehaviour
{
	Rigidbody rb;
	float x, y;
	
	Vector3 direction;

	public float maxSpeed = 10f;
	public float moveSpeed = 5f;
	[Space]
	
	public float jumpForce = 10f;
	int jumpPress;
	bool isGrounded, isRunning;
	
	public Transform head;
	public Transform orientation;
	public Transform groundCheck;
	
	public float checkSize = 1f;
	public LayerMask whatIsGround;
	[Space]
	
	public Vector3 crouchSize;
	Vector3 startSize;
	bool isCrouching = false;

	bool isVolting = false;
	bool headContact, feetContact;
	int hasVolted = 0;
	
    void Start(){
        rb = GetComponent<Rigidbody>();
		startSize = transform.localScale;
    }

    void MyInput(){
		x = Input.GetAxisRaw("Horizontal");
		y = Input.GetAxisRaw("Vertical");
		
		jumpPress = Input.GetKeyDown(KeyCode.Space) ? 1 : 0;
		
		direction = transform.forward * y + transform.right * x;

		if (direction.magnitude == 0){
			rb.drag = 2;
		}else if (direction.magnitude != 0){
			rb.drag = 4;
		}
		
		if (Input.GetKeyDown(KeyCode.LeftControl)){
			isCrouching = true;
		}else if (Input.GetKeyUp(KeyCode.LeftControl)){
			isCrouching = false;
		}
		
		if (Input.GetKeyDown(KeyCode.LeftShift)){
			isRunning = true;
		}else if (Input.GetKeyUp(KeyCode.LeftShift)){
			isRunning = false;
		}
	}
	
    void Update(){
        MyInput();
		DetectVolt();

		isGrounded = Physics.CheckSphere(groundCheck.position, checkSize, whatIsGround);
		if (isCrouching){transform.localScale = crouchSize;}else{transform.localScale = startSize;}
		if (isRunning){moveSpeed = 800;}else{moveSpeed = 500;}
    }
	
	void FixedUpdate(){
		if (rb.velocity.magnitude < maxSpeed){Movement();}
		if (isGrounded){Jump(); hasVolted = 0;}
		
		if (!isGrounded && !isCrouching && isVolting && hasVolted == 0){
			rb.AddForce(transform.up * 12f, ForceMode.Impulse);
			hasVolted = 1;
		}	
	}
	
	void Movement(){
		rb.AddForce(direction.normalized * moveSpeed * Time.fixedDeltaTime, ForceMode.Acceleration);
	}
	
	void Jump(){
		rb.AddForce(transform.up * jumpForce * jumpPress, ForceMode.Impulse);
	}
	
	
	void DetectVolt(){
		headContact = Physics.CheckSphere(head.position, 0.6f, whatIsGround);
		feetContact = Physics.CheckSphere(orientation.position, 0.6f, whatIsGround);

		if (!headContact && feetContact){
			isVolting = true;
		}else{
			isVolting = false;
		}
	}
	
	void PlayEffect(ParticleSystem efx){
		efx.Play();
	}
	
	void StopEffect(ParticleSystem efx){
		efx.Stop();
	}

	void OnDrawGizmosSelected(){
		if (groundCheck == null)
			return;
		
		Debug.DrawLine(groundCheck.position, new Vector3 (groundCheck.position.x, checkSize * -1, groundCheck.position.z), Color.red);
	}
}
