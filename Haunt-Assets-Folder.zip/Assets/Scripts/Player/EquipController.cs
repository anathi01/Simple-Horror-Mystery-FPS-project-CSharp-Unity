﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EquipController : MonoBehaviour
{
    public GameObject objectToEquip;
	
	int set = 1;
	bool isEquipped = false;
	
	void MyInput(){
		if (Input.GetKeyDown(KeyCode.E) || Input.GetKeyDown(KeyCode.F)){
			set *= -1;
		}
	}
	
    void Update(){
        MyInput();
		
		if (set > 0){
			isEquipped = false;
		}else{isEquipped = true;}
		
		EquipObj(objectToEquip);
    }
	
	void EquipObj(GameObject obj){
		obj.SetActive(isEquipped);
	}
}
