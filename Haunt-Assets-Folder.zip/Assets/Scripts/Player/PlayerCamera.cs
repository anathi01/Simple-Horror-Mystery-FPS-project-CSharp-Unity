﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerCamera : MonoBehaviour
{
	float x, y;
	float xAxis, yAxis;
	
	public Transform cam, head;
	public float xSens = 1f, ySens = 1f;
	
	void MyInput(){
		x = Input.GetAxisRaw("Mouse X");
		y = Input.GetAxisRaw("Mouse Y");
	}

    void Update(){
		cam.position = head.position;
		
		MyInput();
		
		xAxis += x * xSens * Time.deltaTime; 
        yAxis -= y * ySens * Time.deltaTime; 
		
		transform.rotation = Quaternion.Euler(0, xAxis, 0);
		
		yAxis = Mathf.Clamp(yAxis, -90f, 90f);
		cam.rotation = Quaternion.Euler(yAxis, xAxis, cam.rotation.z);
    }
}
